<?php 

require "config.php";


if (isset($_POST['save'])) {
	
	$Name = $_POST['Name'];
	$Notel = $_POST['Notel'];
	$Model = $_POST['Model'];
	$Pin = $_POST['Pin'];
	$Date = $_POST['Date'];
	$Time = $_POST['Time'];
	$Sim = $_POST['Sim'];
	$Bspeaker = $_POST['Bspeaker'];
	$Bluetooth = $_POST['Bluetooth'];
	$Tmic = $_POST['Tmic'];
	$Fprint = $_POST['Fprint'];
	$Espeaker = $_POST['Espeaker'];
	$Bhealth = $_POST['Bhealth'];
	$Charging = $_POST['Charging'];
	$Bmic = $_POST['Bmic'];
	$Body = $_POST['Body'];
	$Other = $_POST['Other'];

	$insert = mysqli_query($connect, "INSERT into faceit (Name, Notel, Model, Pin, Date, Time, Sim, Bspeaker, Bluetooth, Tmic, Fprint, Espeaker, Bhealth, Charging, Bmic, Body, Other) VALUES ('".$Name."', '".$Notel."', '".$Model."', '".$Pin."', '".$Date."', '".$Time."', '".$Sim."', '".$Bspeaker."', '".$Bluetooth."', '".$Tmic."', '".$Fprint."', '".$Espeaker."', '".$Bhealth."', '".$Charging."', '".$Bmic."', '".$Body."', '".$Other."')");

	if ($insert) {

		header("location: index.php");

	}else{

		die(mysqli_error($connect));

	}

}

 ?>