<?php 

require "config.php";


 ?>

<!DOCTYPE html>
<html>
<head>
	<link rel="icon" type="image/png" href="image/logo.png">
	<title></title>
	<style type="text/css">
		
		.img1{
			width: 450px;
		}

		.tableHeader{

			width: 75%;
			margin-top: 2%;

		}

		.tablelistheader{

			background-color: red;
			color: white;
			font-size: 20px;

		}

		.tablelist{

			width: 60%;

		}

		.link{
			text-decoration: none;
			color: black;
		}

		a:hover {

			color: red;

		}

	</style>
</head>
<body>	
	<center>
		<table class="tableHeader">
			<tr>
				<td>
					<img src="image/DARKV3.png" class="img1">
				</td>
				<td>
					<nav>
						<table align="center" style="text-align: center;">
							<tr>
								<td style=" width: 50%;"><a href="index.php" class="link" style="font-size: 20px;">LIST</a></td>
								<td style=" width: 50%;"><a href="form.php" class="link" style="font-size: 20px;">INSPECTIONS</a></td>
							</tr>
						</table>
					</nav>
				</td>
			</tr>
		</table>

		<br><br><br><br>

		<table border="1" style="text-align: center; border-radius: 10px; border-collapse: collapse;" class="tablelist">
		<tr>
			<td class="tablelistheader">Customer Name</td>
			<td class="tablelistheader">Phone Model</td>
			<td class="tablelistheader">Contact Number</td>
			<td class="tablelistheader">Date</td>
			<td class="tablelistheader">Time</td>
			<td class="tablelistheader" >Detail</td>
			<td class="tablelistheader" height="50px">Action</td>
		</tr>

		<?php 

			$query = mysqli_query($connect, "SELECT * FROM faceit");

			$check = mysqli_num_rows($query);

			if ($check > 0) {

				while ($show = mysqli_fetch_array($query)) {

				echo"<tr>";
				echo"<td height=\"80\">" .$show['Name']. "</td>";
				echo"<td>" .$show['Model']. "</td>";
				echo"<td>" .$show['Notel']. "</td>";
				echo "<td>" .$show['Date']. "</td>";
				echo "<td>" .$show['Time']. "</td>";

				echo "<td><button><a href=\"viewdetail.php?No=$show[No]\" class=\"link\"><img src=\"image/view.png\" height = \"30\"><br>View</a></button>";

				echo "<td><button style=\"align\"><a href=\"update.php?No=$show[No]\" class=\"link\"><img src=\"image/update.png\" width=\"30\"><br>Edit</a></button>  &nbsp; &nbsp; 

				<button><a href=\"delete.php?No=$show[No]\" class=\"link\"><img src=\"image/delete.png\" width = \"30\" title=\"Delete\"><br>Delete</a></button>  &nbsp; &nbsp; 

				<button><a href=\"call.php?No=$show[No]\" class=\"link\"><img src=\"image/call.png\" width = \"30\" title=\"Contact\"><br>Contact</a>";

				echo"</tr>";

				}

			}
			else{

				echo "<table><tr><p>Database Empty</p></tr></table>";

			}

		 ?>

	</table>

	<br><br><br><a href="form.php" class="link">Add Checklist Inspections</a>

		</center>
</body>
</html>